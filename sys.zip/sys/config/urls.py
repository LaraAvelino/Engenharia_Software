from django.contrib import admin
from django.urls import path
from django.views.generic import TemplateView
from app.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', TemplateView.as_view(template_name='index.html'), name ='index'),
    path('matricula/', matricula, name ='matriculas'),
    path('avaliacao_curso/', avaliacao_curso, name ='avaliacoes_cursos'),
    path('frequencia/', frequencia, name ='frequencias'),
    path('ocorrencia/', ocorrencia, name ='ocorrencias'),
    path('disciplina_curso/', disciplina_curso, name ='disciplinas_cursos'),
]


