from django.db import models

class Cidade(models.Model):
    nome = models.CharField(max_length=255)
    uf = models.CharField(max_length=2)

    def __str__(self):
        return f'{self.nome} {self.uf}'
    
class Ocupacao(models.Model):
    nome = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.nome}'
    
class Instituicao(models.Model):
    nome = models.CharField(max_length=255)
    site = models.CharField(max_length=255)
    telefone = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.nome} {self.site} {self.telefone}'
    
class Area(models.Model):
    nome = models.CharField(max_length=255)
    
    def __str__(self):
        return f'{self.nome}'
    
class Periodo(models.Model):
    periodo = models.CharField(max_length=255)
    
    def __str__(self):
        return f'{self.periodo}'

class Turma(models.Model):
    nome = models.CharField(max_length=255)
    periodo = models.CharField(max_length=255)

    
    def __str__(self):
        return f'{self.nome} {self.periodo}'

class Avaliacao(models.Model):
    tipos = models.CharField(max_length=255)
    
    def __str__(self):
        return f'{self.tipos}'
    
                            
class Pessoa(models.Model):
    nome = models.CharField(max_length=255)
    pai = models.CharField(max_length=255)
    mae = models.CharField(max_length=255)
    cpf = models.CharField(max_length=255)
    data_nasc = models.DateField()
    email = models.CharField(max_length=255)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.nome} {self.pai} {self.mae} {self.cpf} {self.data_nasc} {self.email} {self.cidade}'
    
class Curso(models.Model):
    nome = models.CharField(max_length=255)
    carga_hor = models.DecimalField(max_digits=6,decimal_places=2)
    duracao_meses = models.CharField(max_length=255)
    area = models.ForeignKey(Area, on_delete=models.CASCADE)
    instituicao = models.ForeignKey(Instituicao, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.nome} {self.carga_hor} {self.duracao_meses} ? {self.instituicao}'
    
class Disciplina(models.Model):
    nome = models.CharField(max_length=255)
    Area = models.ForeignKey(Area, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.nome} {self.Area}'

    
class Matricula(models.Model):
    instituicao = models.ForeignKey(Instituicao, on_delete=models.CASCADE)
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE)
    pessoa = models.ForeignKey(Pessoa, on_delete=models.CASCADE)
    data_ini = models.DateField()
    data_prev = models.DateField()

    def __str__(self):
        return f'{self.instituicao} {self.curso} {self.pessoa} {self.data_ini} {self.data_prev}'

class Avaliacao_curso(models.Model):
    descricao = models.CharField(max_length=255)
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE)
    disciplina = models.ForeignKey(Disciplina, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.descricao} {self.curso} {self.disciplina}'
    
class Frequencia(models.Model):
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE)
    disciplina = models.ForeignKey(Disciplina, on_delete=models.CASCADE)
    falta = models.PositiveIntegerField

    def __str__(self):
        return f'{self.curso} {self.disciplina} {self.falta}'

class Ocorrencia(models.Model):
    descricao = models.CharField(max_length=255)
    data = models.DateField()
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE)
    disciplina = models.ForeignKey(Disciplina, on_delete=models.CASCADE)
    pessoa = models.ForeignKey(Pessoa, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.descricao} {self.data} {self.curso} {self.disciplina} {self.pessoa}'

class Disciplina_curso(models.Model):
    nome = models.CharField(max_length=255)
    carga_hor = models.DecimalField(max_digits=6,decimal_places=2)
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE)
    periodo = models.ForeignKey(Periodo, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.nome} {self.carga_hor} {self.curso} {self.periodo}'
    