from django.contrib import admin
from app.models import *

admin.site.register(Cidade)
admin.site.register(Ocupacao)
admin.site.register(Instituicao)
admin.site.register(Area)
admin.site.register(Periodo)
admin.site.register(Turma)
admin.site.register(Avaliacao)
admin.site.register(Pessoa)
admin.site.register(Curso)
admin.site.register(Disciplina)
admin.site.register(Matricula)
admin.site.register(Avaliacao_curso)
admin.site.register(Frequencia)
admin.site.register(Ocorrencia)
admin.site.register(Disciplina_curso)